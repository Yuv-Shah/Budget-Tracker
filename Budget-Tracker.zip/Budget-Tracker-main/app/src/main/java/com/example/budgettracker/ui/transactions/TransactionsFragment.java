package com.example.budgettracker.ui.transactions;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.budgettracker.R;
import com.example.budgettracker.data.TransactionManager;
import com.example.budgettracker.model.Transaction;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class TransactionsFragment extends Fragment {

    private TransactionAdapter adapter;
    private TabLayout tabLayout;
    private final List<Transaction> displayedTransactions = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);

        tabLayout = view.findViewById(R.id.tabLayoutTransactions);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerViewTransactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new TransactionAdapter(displayedTransactions);
        recyclerView.setAdapter(adapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterTransactions(tab.getPosition() == 1);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        Button btnAdd = view.findViewById(R.id.btnAddTransactionAction);
        btnAdd.setOnClickListener(v ->
                TransactionDialogHelper.showAddTransactionDialog(requireContext(), isIncome -> {
                    if (isIncome && tabLayout.getSelectedTabPosition() != 1) {
                        TabLayout.Tab tab = tabLayout.getTabAt(1);
                        if (tab != null) tab.select();
                    } else if (!isIncome && tabLayout.getSelectedTabPosition() != 0) {
                        TabLayout.Tab tab = tabLayout.getTabAt(0);
                        if (tab != null) tab.select();
                    } else {
                        filterTransactions(tabLayout.getSelectedTabPosition() == 1);
                    }
                })
        );

        filterTransactions(false);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (tabLayout != null) {
            filterTransactions(tabLayout.getSelectedTabPosition() == 1);
        }
    }

    private void filterTransactions(boolean showIncome) {
        List<Transaction> all = TransactionManager.getInstance().getTransactions();
        List<Transaction> filtered = new ArrayList<>();
        for (Transaction t : all) {
            if (t.isIncome() == showIncome) {
                filtered.add(t);
            }
        }
        adapter.updateList(filtered);
    }
}
